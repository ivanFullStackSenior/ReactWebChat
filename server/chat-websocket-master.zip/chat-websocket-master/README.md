chat-websocket
=============

a very simple chat demo using websocket

>npm install

>node app.js
